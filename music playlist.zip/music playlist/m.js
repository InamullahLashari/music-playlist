let song = document.querySelector("#song");
let audioSource = document.querySelector("#audioSource");
let playPauseButton = document.querySelector("#playPause i");
let progress = document.querySelector("#progress");
let forwardButton = document.querySelector("#forward");
let backwardButton = document.querySelector("#backward");

let songIndex = 0;
let songs = [
    
    { src: "heer.mp3", title: "HEER RANJHA", artist: "ARIGIT SONG" },
    { src: "SaveTube.App - Ilahi Full Video Song _ Yeh Jawaani Hai Deewani _ Ranbir Kapoor, Deepika Padukone _ Pritam (128 kbps).mp3", title: "TUM HI HO", artist: "ARIGIT SONG" },
    { src: "song3.mp3", title: "SANAM RE", artist: "ARIGIT SONG" }
];

// Update the song and display info
function loadSong(index) {
    if (index >= -1 && index < songs.length) {
        audioSource.src = songs[index].src;
        document.querySelector(".txt h1").textContent = songs[index].artist;
        document.querySelector(".txt p").textContent = songs[index].title;
        song.load();
        playSong();
    }
}

// Play song and update play/pause icon
function playSong() {
    song.play();
    playPauseButton.classList.remove("fa-play");
    playPauseButton.classList.add("fa-pause");
}

// Pause song and update play/pause icon
function pauseSong() {
    song.pause();
    playPauseButton.classList.remove("fa-pause");
    playPauseButton.classList.add("fa-play");
}

// Play/pause toggle function
function playpause() {
    // Reset the song to the start when play is clicked
    song.currentTime = 0; 

    if (song.paused) {
        playSong();
    } else {
        pauseSong();
    }
}

// Change song on forward/backward click
forwardButton.addEventListener("click", () => {
    songIndex = (songIndex + 1) % songs.length;
    loadSong(songIndex);
});

backwardButton.addEventListener("click", () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSong(songIndex);
});

// Play/pause button functionality
playPauseButton.parentElement.addEventListener("click", playpause);

// Set progress bar max on song load
song.onloadedmetadata = function() {
    progress.max = song.duration;
    progress.value = song.currentTime;
};

// Update song time when progress bar changes
progress.oninput = function() {
    song.currentTime = progress.value;
};

// Update progress bar as song plays
song.ontimeupdate = function() {
    progress.value = song.currentTime;
};
